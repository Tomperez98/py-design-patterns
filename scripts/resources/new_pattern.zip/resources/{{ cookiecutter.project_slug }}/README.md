# Pattern Name: {{ cookiecutter.pattern_name }}

## How it works

Add explanation here

## Explanatory diagram

Add diagram here (Please use mermaid)
