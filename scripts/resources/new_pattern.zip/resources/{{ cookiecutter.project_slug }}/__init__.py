from .main import pattern_name

__all__ = [
    "pattern_name",
]
