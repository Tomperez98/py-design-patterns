def pattern_name() -> str:
    return "{{cookiecutter.project_slug}}"
