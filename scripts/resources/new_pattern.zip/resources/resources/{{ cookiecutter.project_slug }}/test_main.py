from patterns import {{cookiecutter.project_slug}}


def test_pattern_name():
    assert {{cookiecutter.project_slug}}.pattern_name() == "{{cookiecutter.project_slug}}"
